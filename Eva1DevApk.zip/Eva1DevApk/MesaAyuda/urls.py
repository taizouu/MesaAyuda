"""
URL configuration for MesaAyuda project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from AppAyuda import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('', views.user_login, name='login'),
    path('logout/', views.user_logout, name='user_logout'),
    path('crear/', views.crear_tique, name='crear_tique'),
    path('detalle/<int:tique_id>/', views.detalle_tique, name='detalle_tique'),
    path('lista/', views.lista_tiques, name='lista_tiques'),
    path('previsualizar/<int:tique_id>/', views.previsualizar_tique, name='previsualizar_tique'),
    path('terminos_condiciones/', views.terminos_condiciones, name='terminos_condiciones'),
    path('editar_tique/<int:tique_id>/', views.editar_tique, name='editar_tique'),
    path('borrar_tique/<int:tique_id>/', views.borrar_tique, name='borrar_tique'),
]
