from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .forms import TicketForm, UserRegisterForm
from .models import Ticket

def home(request):
    return render(request, 'home.html')


@login_required
def crear_tique(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            nuevo_tique = form.save(commit=False)
            nuevo_tique.ejecutivo_asignado = request.user
            nuevo_tique.save()
            return redirect('detalle_tique', tique_id=nuevo_tique.id)
    else:
        form = TicketForm()
    return render(request, 'crear_tique.html', {'form': form})

@login_required
def detalle_tique(request, tique_id):
    tique = get_object_or_404(Ticket, id=tique_id)
    if request.method == 'POST':
        observaciones = request.POST.get('observaciones')
        if observaciones:
            tique.observaciones = observaciones
            tique.ejecutivo_cierre = request.user
            tique.estado = 'resuelto'
            tique.save()
            return redirect('lista_tiques')
    return render(request, 'detalle_tique.html', {'tique': tique})


@login_required
def lista_tiques(request):
    tiques = Ticket.objects.all()

    fecha_especifica = request.GET.get('fecha_especifica')
    criticidad = request.GET.get('criticidad')
    tipo = request.GET.get('tipo')
    ejecutivo_abre = request.GET.get('ejecutivo_abre')
    ejecutivo_cierra = request.GET.get('ejecutivo_cierra')
    area = request.GET.get('area')

    filtros = Q()
    if fecha_especifica:
        filtros &= Q(fecha_creacion__date=fecha_especifica)
    if criticidad:
        filtros &= Q(criticidad=criticidad)
    if tipo:
        filtros &= Q(tipo=tipo)
    if ejecutivo_abre:
        filtros &= Q(ejecutivo_asignado__username=ejecutivo_abre)
    if ejecutivo_cierra:
        filtros &= Q(ejecutivo_cierre__username=ejecutivo_cierra)
    if area:
        filtros &= Q(area_resolucion=area)

    tiques = tiques.filter(filtros)

    return render(request, 'lista_tiques.html', {'tiques': tiques})

@login_required
def editar_tique(request, tique_id):
    tique = get_object_or_404(Ticket, id=tique_id)
    if request.method == "POST":
        form = TicketForm(request.POST, instance=tique)
        if form.is_valid():
            form.save()
            return redirect('detalle_tique', tique_id=tique.id)
    else:
        form = TicketForm(instance=tique)
    return render(request, 'editar_tique.html', {'form': form})

@login_required
def borrar_tique(request, tique_id):
    tique = get_object_or_404(Ticket, id=tique_id)
    if request.method == "POST":
        tique.delete()
        return redirect('lista_tiques')
    return render(request, 'borrar_tique.html', {'tique': tique})

def previsualizar_tique(request, tique_id):
    tique = get_object_or_404(Ticket, id=tique_id)
    return render(request, 'previsualizar_tique.html', {'tique': tique})

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Usuario {username} creado con éxito. ¡Bienvenido!')
            return redirect('home')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Nombre de usuario o contraseña no válidos')
    return render(request, 'login.html')

@login_required
def user_logout(request):
    logout(request)
    return redirect('home')

def terminos_condiciones(request):
    return render(request, 'terminos_condiciones.html')
