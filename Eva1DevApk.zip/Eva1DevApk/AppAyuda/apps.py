from django.apps import AppConfig


class AppayudaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppAyuda'
