from django import forms
from .models import Ticket, User
from django.contrib.auth.forms import UserCreationForm

class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['nombre_cliente', 'rut_cliente', 'telefono', 'correo', 'tipo', 'criticidad', 'estado', 'detalle_servicio', 'detalle_problema', 'area_derivacion', 'fecha_creacion']


class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(label='Correo Electrónico')

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        labels = {
            'username': 'Nombre de Usuario'
        }
