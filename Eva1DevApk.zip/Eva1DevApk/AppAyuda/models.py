from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Ticket(models.Model):
    TIPO_CHOICES = [
        ('felicitacion', 'Felicitación'),
        ('consulta', 'Consulta'),
        ('reclamo', 'Reclamo'),
        ('problema', 'Problema'),
    ]

    CRITICIDAD_CHOICES = [
        ('baja', 'Baja'),
        ('media', 'Media'),
        ('alta', 'Alta'),
    ]

    ESTADO_CHOICES = [
        ('a_resolucion', 'A resolución'),
        ('resuelto', 'Resuelto'),
        ('no_aplicable', 'No aplicable'),
    ]

    id = models.AutoField(primary_key=True) 
    nombre_cliente = models.CharField(max_length=100)
    rut_cliente = models.CharField(max_length=12)
    telefono = models.CharField(max_length=15)
    correo = models.EmailField()
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES)
    criticidad = models.CharField(max_length=10, choices=CRITICIDAD_CHOICES)
    detalle_servicio = models.CharField(max_length=500)
    detalle_problema = models.CharField(max_length=500)
    area_derivacion = models.CharField(max_length=100)
    ejecutivo_asignado = models.ForeignKey(User, on_delete=models.CASCADE, related_name='tickets_asignados', blank=True, null=True)
    area_resolucion = models.CharField(max_length=100, blank=True, null=True)
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='a_resolucion')
    observaciones = models.TextField(blank=True, null=True)
    ejecutivo_cierre = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='tickets_cerrados', blank=True, null=True)
    fecha_creacion = models.DateTimeField(default=timezone.now)
    fecha_modificacion = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Ticket #{self.id}: {self.nombre_cliente}'
    
class PerfilCliente(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

class PerfilEjecutivo(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

class PerfilJefeMesa(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
